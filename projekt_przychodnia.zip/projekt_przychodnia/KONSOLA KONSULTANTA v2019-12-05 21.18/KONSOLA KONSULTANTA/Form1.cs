﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SimpleTCP;
using System.Net;

namespace KONSOLA_KONSULTANTA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SimpleTcpServer serwer;
        SimpleTcpClient client;
        private void Form1_Load(object sender, EventArgs e)
        {
            //INICJALIZOWANIE SERWERA
            serwer = new SimpleTcpServer();
            serwer.Delimiter = 0x13;
            serwer.StringEncoder = Encoding.UTF8;
            serwer.DataReceived += Serwer_DataReceived; ;
            //INICJALIZOWANIE KLIENTA
            client = new SimpleTcpClient();
            client.StringEncoder = Encoding.UTF8;
            client.DataReceived += Client_DataReceived; ;
        }

        private void Serwer_DataReceived(object sender, SimpleTCP.Message e)
        {
            txt_dialog.Invoke((MethodInvoker)delegate ()
            {
                txt_dialog.Text += e.MessageString;
                e.ReplyLine(string.Format("TWOJA ODP: {0}", e.MessageString));
            });
        }

        private void Client_DataReceived(object sender, SimpleTCP.Message e)
        {
            txt_dialog.Invoke((MethodInvoker)delegate ()
            {
                txt_dialog.Text += e.MessageString;
            });
        }

        private void button_STOP_Click(object sender, EventArgs e)
        {
            if (serwer.IsStarted)
                serwer.Stop();
        }

        private void button_polacz_Click_1(object sender, EventArgs e)
        {
                button_polacz.Enabled = false;
                //Połączenie do serwera
                client.Connect(txt_klient_adres.Text, Convert.ToInt32(txt_klient_port.Text));
        }

        private void button_Start_Click_1(object sender, EventArgs e)
        {
                IPAddress ip = IPAddress.Parse(txt_serwer_adres.Text);
                serwer.Start(ip, Convert.ToInt32(txt_serwer_port.Text));
        }

        private void button_wyslij_Click_1(object sender, EventArgs e)
        {
                client.WriteLineAndGetReply(textBox_tresc.Text + "\r\n", TimeSpan.FromSeconds(1));
            textBox_tresc.Text = "";
        }

       
    }
}
