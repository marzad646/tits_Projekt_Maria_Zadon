﻿namespace KONSOLA_KONSULTANTA
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_STOP = new System.Windows.Forms.Button();
            this.button_Start = new System.Windows.Forms.Button();
            this.txt_serwer_port = new System.Windows.Forms.TextBox();
            this.txt_serwer_adres = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button_wyslij = new System.Windows.Forms.Button();
            this.txt_dialog = new System.Windows.Forms.TextBox();
            this.textBox_tresc = new System.Windows.Forms.TextBox();
            this.button_polacz = new System.Windows.Forms.Button();
            this.txt_klient_port = new System.Windows.Forms.TextBox();
            this.txt_klient_adres = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button_STOP
            // 
            this.button_STOP.Location = new System.Drawing.Point(552, 88);
            this.button_STOP.Name = "button_STOP";
            this.button_STOP.Size = new System.Drawing.Size(75, 23);
            this.button_STOP.TabIndex = 32;
            this.button_STOP.Text = "STOP";
            this.button_STOP.UseVisualStyleBackColor = true;
            this.button_STOP.Click += new System.EventHandler(this.button_STOP_Click);
            // 
            // button_Start
            // 
            this.button_Start.Location = new System.Drawing.Point(471, 88);
            this.button_Start.Name = "button_Start";
            this.button_Start.Size = new System.Drawing.Size(75, 23);
            this.button_Start.TabIndex = 31;
            this.button_Start.Text = "START";
            this.button_Start.UseVisualStyleBackColor = true;
            this.button_Start.Click += new System.EventHandler(this.button_Start_Click_1);
            // 
            // txt_serwer_port
            // 
            this.txt_serwer_port.Location = new System.Drawing.Point(351, 90);
            this.txt_serwer_port.Name = "txt_serwer_port";
            this.txt_serwer_port.Size = new System.Drawing.Size(100, 20);
            this.txt_serwer_port.TabIndex = 30;
            this.txt_serwer_port.Text = "8920";
            // 
            // txt_serwer_adres
            // 
            this.txt_serwer_adres.Location = new System.Drawing.Point(138, 90);
            this.txt_serwer_adres.Name = "txt_serwer_adres";
            this.txt_serwer_adres.Size = new System.Drawing.Size(100, 20);
            this.txt_serwer_adres.TabIndex = 29;
            this.txt_serwer_adres.Text = "127.0.0.1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 13);
            this.label3.TabIndex = 28;
            this.label3.Text = "SERWER ADRES:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(254, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 13);
            this.label4.TabIndex = 27;
            this.label4.Text = "SERWER PORT:";
            // 
            // button_wyslij
            // 
            this.button_wyslij.Location = new System.Drawing.Point(30, 399);
            this.button_wyslij.Name = "button_wyslij";
            this.button_wyslij.Size = new System.Drawing.Size(746, 23);
            this.button_wyslij.TabIndex = 26;
            this.button_wyslij.Text = "WYŚLIJ OPIS KONSULTACJI";
            this.button_wyslij.UseVisualStyleBackColor = true;
            this.button_wyslij.Click += new System.EventHandler(this.button_wyslij_Click_1);
            // 
            // txt_dialog
            // 
            this.txt_dialog.Location = new System.Drawing.Point(30, 134);
            this.txt_dialog.Multiline = true;
            this.txt_dialog.Name = "txt_dialog";
            this.txt_dialog.Size = new System.Drawing.Size(748, 121);
            this.txt_dialog.TabIndex = 25;
            // 
            // textBox_tresc
            // 
            this.textBox_tresc.Location = new System.Drawing.Point(28, 281);
            this.textBox_tresc.Multiline = true;
            this.textBox_tresc.Name = "textBox_tresc";
            this.textBox_tresc.Size = new System.Drawing.Size(748, 93);
            this.textBox_tresc.TabIndex = 24;
            // 
            // button_polacz
            // 
            this.button_polacz.Location = new System.Drawing.Point(471, 48);
            this.button_polacz.Name = "button_polacz";
            this.button_polacz.Size = new System.Drawing.Size(75, 23);
            this.button_polacz.TabIndex = 23;
            this.button_polacz.Text = "POLACZ";
            this.button_polacz.UseVisualStyleBackColor = true;
            this.button_polacz.Click += new System.EventHandler(this.button_polacz_Click_1);
            // 
            // txt_klient_port
            // 
            this.txt_klient_port.Location = new System.Drawing.Point(351, 50);
            this.txt_klient_port.Name = "txt_klient_port";
            this.txt_klient_port.Size = new System.Drawing.Size(100, 20);
            this.txt_klient_port.TabIndex = 22;
            this.txt_klient_port.Text = "8910";
            // 
            // txt_klient_adres
            // 
            this.txt_klient_adres.Location = new System.Drawing.Point(138, 50);
            this.txt_klient_adres.Name = "txt_klient_adres";
            this.txt_klient_adres.Size = new System.Drawing.Size(100, 20);
            this.txt_klient_adres.TabIndex = 21;
            this.txt_klient_adres.Text = "127.0.0.1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 13);
            this.label2.TabIndex = 20;
            this.label2.Text = "KLIENT ADRES:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(254, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "KLIENT PORT:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_STOP);
            this.Controls.Add(this.button_Start);
            this.Controls.Add(this.txt_serwer_port);
            this.Controls.Add(this.txt_serwer_adres);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button_wyslij);
            this.Controls.Add(this.txt_dialog);
            this.Controls.Add(this.textBox_tresc);
            this.Controls.Add(this.button_polacz);
            this.Controls.Add(this.txt_klient_port);
            this.Controls.Add(this.txt_klient_adres);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "KONSOLA KONSULTANTA";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_STOP;
        private System.Windows.Forms.Button button_Start;
        private System.Windows.Forms.TextBox txt_serwer_port;
        private System.Windows.Forms.TextBox txt_serwer_adres;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_wyslij;
        private System.Windows.Forms.TextBox txt_dialog;
        private System.Windows.Forms.TextBox textBox_tresc;
        private System.Windows.Forms.Button button_polacz;
        private System.Windows.Forms.TextBox txt_klient_port;
        private System.Windows.Forms.TextBox txt_klient_adres;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

