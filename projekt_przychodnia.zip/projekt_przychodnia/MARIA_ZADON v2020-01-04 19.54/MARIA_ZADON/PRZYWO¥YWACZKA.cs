﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Timers;
using System.Threading;

namespace MARIA_ZADON
{
    public partial class PRZYWOŁYWACZKA : Form
    {
        public string cmd_szukaj_wizyty;
        public string cmd_przyjmowany_pacjent;
        public string cmd_wzywany_pacjent;
        public int przyjmowany;
        public int wzywany;

        REJESTRACJA r = new REJESTRACJA();
        public PRZYWOŁYWACZKA()
        {
            InitializeComponent();
            Przywoływaczka_Data_Grid_Wizyty();
            przyjmowany_pacjent();
            timer1.Start();
        }
       

       
        public void Przywoływaczka_Data_Grid_Wizyty()
        {
            dataGridView1.DataSource = Lista_Wizyt();
        }

        private DataTable Lista_Wizyt()
        {
            
            cmd_szukaj_wizyty = string.Format("SELECT DATE_FORMAT(wiz.godz_rozp,  \"%H:%i\") as PLANOWANA_GODZINA_ROZPOCZECIA_WIZYTY, DATE_FORMAT(wiz.godz_zak,  \"%H:%i\")  as PLANOWANA_GODZINA_ZAKOŃCZENIA_WIZYTY, pac.PAC_ID as NR_IDENTYFIKACYJNY FROM `wizyta` wiz, `pacjent` pac where wiz.pac_id=pac.pac_id and status = 'P' and DATA_WIZYTY = DATE_FORMAT(sysdate(),  \"%Y-%m-%d\") order by wiz.godz_rozp;");
            DataTable Wizyty = new DataTable();
            MySqlCommand cmd = new MySqlCommand(cmd_szukaj_wizyty, r.con);
            MySqlDataReader czytnik = cmd.ExecuteReader();
            Wizyty.Load(czytnik);
            return Wizyty;
            

        }
     

        public void przyjmowany_pacjent()
        {
            cmd_przyjmowany_pacjent = string.Format("select PAC_ID from wizyta where STATUS = 'R';");
            cmd_wzywany_pacjent = string.Format("select PAC_ID from wizyta where STATUS = 'W';");
            MySqlCommand cmd_pr = new MySqlCommand(cmd_przyjmowany_pacjent, r.con);
            MySqlCommand cmd_wz = new MySqlCommand(cmd_wzywany_pacjent, r.con);

            try
            {
                
                przyjmowany = (int)cmd_pr.ExecuteScalar();
            }
            catch (Exception)
            {
            }
            try
            {
                wzywany = (int)cmd_wz.ExecuteScalar();
                
            }
            catch (Exception)
            {
            }

            if (wzywany > 0)
            {
                label1.Text = "OSOBA Z NUMEREM " + wzywany.ToString() + " PROSZONA JEST O WEJŚCIE DO GABINETU";
            }
            else if (przyjmowany > 0)
            {
                label1.Text = "OSOBA Z NUMEREM " + przyjmowany.ToString() + " PRZEBYWA W GABINECIE";
            }
            else
            {
                label1.Text = "PROSZĘ CZEKAĆ NA WEZWANIE";
            }
            przyjmowany = 0;
            wzywany = 0;

        }



        private void timer1_Tick(object sender, EventArgs e)
        {
            Przywoływaczka_Data_Grid_Wizyty();
            przyjmowany_pacjent();
        }

    }
}
