﻿namespace MARIA_ZADON
{
    partial class GABINET
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button_odświerz = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button_przywołaj = new System.Windows.Forms.Button();
            this.dzien_przyjęcia = new System.Windows.Forms.DateTimePicker();
            this.button_przyjmij = new System.Windows.Forms.Button();
            this.textBox_opis_badania = new System.Windows.Forms.TextBox();
            this.textBox_zalecenia = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label_nazwisko_imiona = new System.Windows.Forms.Label();
            this.label_pesel = new System.Windows.Forms.Label();
            this.label_wiek = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label_plec = new System.Windows.Forms.Label();
            this.label_data_urodzenia = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.textBox_kod_icd = new System.Windows.Forms.TextBox();
            this.button_szukaj_kodu_ICD = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(25, 63);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(573, 205);
            this.dataGridView1.TabIndex = 0;
            // 
            // button_odświerz
            // 
            this.button_odświerz.Location = new System.Drawing.Point(444, 287);
            this.button_odświerz.Name = "button_odświerz";
            this.button_odświerz.Size = new System.Drawing.Size(154, 23);
            this.button_odświerz.TabIndex = 1;
            this.button_odświerz.Text = "ODŚWIEŻ";
            this.button_odświerz.UseVisualStyleBackColor = true;
            this.button_odświerz.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button_przywołaj);
            this.groupBox1.Controls.Add(this.dzien_przyjęcia);
            this.groupBox1.Controls.Add(this.button_przyjmij);
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Controls.Add(this.button_odświerz);
            this.groupBox1.Location = new System.Drawing.Point(629, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(623, 316);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lista Pacjentów do Przyjęcia";
            // 
            // button_przywołaj
            // 
            this.button_przywołaj.Location = new System.Drawing.Point(25, 287);
            this.button_przywołaj.Name = "button_przywołaj";
            this.button_przywołaj.Size = new System.Drawing.Size(154, 23);
            this.button_przywołaj.TabIndex = 4;
            this.button_przywołaj.Text = "PRZYWOŁAJ";
            this.button_przywołaj.UseVisualStyleBackColor = true;
            this.button_przywołaj.Click += new System.EventHandler(this.button_przywołaj_Click);
            // 
            // dzien_przyjęcia
            // 
            this.dzien_przyjęcia.Location = new System.Drawing.Point(25, 37);
            this.dzien_przyjęcia.Name = "dzien_przyjęcia";
            this.dzien_przyjęcia.Size = new System.Drawing.Size(200, 20);
            this.dzien_przyjęcia.TabIndex = 3;
            // 
            // button_przyjmij
            // 
            this.button_przyjmij.Location = new System.Drawing.Point(237, 287);
            this.button_przyjmij.Name = "button_przyjmij";
            this.button_przyjmij.Size = new System.Drawing.Size(154, 23);
            this.button_przyjmij.TabIndex = 2;
            this.button_przyjmij.Text = "PRZYJMIJ";
            this.button_przyjmij.UseVisualStyleBackColor = true;
            this.button_przyjmij.Click += new System.EventHandler(this.button_przyjmij_Click);
            // 
            // textBox_opis_badania
            // 
            this.textBox_opis_badania.Location = new System.Drawing.Point(28, 334);
            this.textBox_opis_badania.Multiline = true;
            this.textBox_opis_badania.Name = "textBox_opis_badania";
            this.textBox_opis_badania.Size = new System.Drawing.Size(1175, 139);
            this.textBox_opis_badania.TabIndex = 3;
            // 
            // textBox_zalecenia
            // 
            this.textBox_zalecenia.Location = new System.Drawing.Point(28, 512);
            this.textBox_zalecenia.Multiline = true;
            this.textBox_zalecenia.Name = "textBox_zalecenia";
            this.textBox_zalecenia.Size = new System.Drawing.Size(1006, 142);
            this.textBox_zalecenia.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 315);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Opis Badania:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 496);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Zalecenia:";
            // 
            // label_nazwisko_imiona
            // 
            this.label_nazwisko_imiona.AutoSize = true;
            this.label_nazwisko_imiona.Location = new System.Drawing.Point(6, 28);
            this.label_nazwisko_imiona.Name = "label_nazwisko_imiona";
            this.label_nazwisko_imiona.Size = new System.Drawing.Size(109, 13);
            this.label_nazwisko_imiona.TabIndex = 7;
            this.label_nazwisko_imiona.Text = "NAZWISKO_IMIONA";
            // 
            // label_pesel
            // 
            this.label_pesel.AutoSize = true;
            this.label_pesel.Location = new System.Drawing.Point(6, 44);
            this.label_pesel.Name = "label_pesel";
            this.label_pesel.Size = new System.Drawing.Size(41, 13);
            this.label_pesel.TabIndex = 8;
            this.label_pesel.Text = "PESEL";
            // 
            // label_wiek
            // 
            this.label_wiek.AutoSize = true;
            this.label_wiek.Location = new System.Drawing.Point(229, 44);
            this.label_wiek.Name = "label_wiek";
            this.label_wiek.Size = new System.Drawing.Size(35, 13);
            this.label_wiek.TabIndex = 4;
            this.label_wiek.Text = "WIEK";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label_plec);
            this.groupBox2.Controls.Add(this.label_data_urodzenia);
            this.groupBox2.Controls.Add(this.label_nazwisko_imiona);
            this.groupBox2.Controls.Add(this.label_wiek);
            this.groupBox2.Controls.Add(this.label_pesel);
            this.groupBox2.Location = new System.Drawing.Point(28, 37);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(595, 82);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Przyjęty Pacjent";
            // 
            // label_plec
            // 
            this.label_plec.AutoSize = true;
            this.label_plec.Location = new System.Drawing.Point(229, 28);
            this.label_plec.Name = "label_plec";
            this.label_plec.Size = new System.Drawing.Size(35, 13);
            this.label_plec.TabIndex = 10;
            this.label_plec.Text = "PŁEĆ";
            // 
            // label_data_urodzenia
            // 
            this.label_data_urodzenia.AutoSize = true;
            this.label_data_urodzenia.Location = new System.Drawing.Point(98, 44);
            this.label_data_urodzenia.Name = "label_data_urodzenia";
            this.label_data_urodzenia.Size = new System.Drawing.Size(106, 13);
            this.label_data_urodzenia.TabIndex = 9;
            this.label_data_urodzenia.Text = "DATA_URODZENIA";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1040, 624);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(200, 46);
            this.button1.TabIndex = 10;
            this.button1.Text = "ZAPISZ DANE WIZYTY";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_zakoncz_wizyte);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToOrderColumns = true;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(28, 159);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(595, 150);
            this.dataGridView2.TabIndex = 11;
            // 
            // textBox_kod_icd
            // 
            this.textBox_kod_icd.Location = new System.Drawing.Point(28, 133);
            this.textBox_kod_icd.Name = "textBox_kod_icd";
            this.textBox_kod_icd.Size = new System.Drawing.Size(204, 20);
            this.textBox_kod_icd.TabIndex = 12;
            // 
            // button_szukaj_kodu_ICD
            // 
            this.button_szukaj_kodu_ICD.Location = new System.Drawing.Point(283, 131);
            this.button_szukaj_kodu_ICD.Name = "button_szukaj_kodu_ICD";
            this.button_szukaj_kodu_ICD.Size = new System.Drawing.Size(75, 23);
            this.button_szukaj_kodu_ICD.TabIndex = 13;
            this.button_szukaj_kodu_ICD.Text = "SZUKAJ";
            this.button_szukaj_kodu_ICD.UseVisualStyleBackColor = true;
            this.button_szukaj_kodu_ICD.Click += new System.EventHandler(this.button_szukaj_kodu_ICD_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1040, 512);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(200, 46);
            this.button2.TabIndex = 14;
            this.button2.Text = "OTWÓRZ OKNO KONSULTACJI";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1040, 564);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(200, 46);
            this.button3.TabIndex = 15;
            this.button3.Text = "HISTORIA";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // GABINET
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 682);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button_szukaj_kodu_ICD);
            this.Controls.Add(this.textBox_kod_icd);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_zalecenia);
            this.Controls.Add(this.textBox_opis_badania);
            this.Controls.Add(this.groupBox1);
            this.Name = "GABINET";
            this.Text = "GABINET";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button_odświerz;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button_przyjmij;
        private System.Windows.Forms.DateTimePicker dzien_przyjęcia;
        private System.Windows.Forms.TextBox textBox_opis_badania;
        private System.Windows.Forms.TextBox textBox_zalecenia;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label_nazwisko_imiona;
        private System.Windows.Forms.Label label_pesel;
        private System.Windows.Forms.Label label_wiek;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label_plec;
        private System.Windows.Forms.Label label_data_urodzenia;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox textBox_kod_icd;
        private System.Windows.Forms.Button button_szukaj_kodu_ICD;
        private System.Windows.Forms.Button button_przywołaj;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}