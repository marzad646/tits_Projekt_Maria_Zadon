﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MARIA_ZADON
{
    public partial class HISTORIA : Form
    {   
        public string cmd_historia;
        REJESTRACJA r = new REJESTRACJA();
        public HISTORIA()
        {
            InitializeComponent();
        }

        public void Historia_Data_Grid_Wizyty()
        {
            dataGridView1.DataSource = Lista_Hist();
        }

        private DataTable Lista_Hist()
        {
            if (radioButton1.Checked == true)
            {
                cmd_historia = string.Format("SELECT DATA_WIZYTY,ROZP_CHOR,OPIS_BAD,ZALEC FROM `wizyta` WHERE PAC_ID = '{0}' order by DATA_WIZYTY ", GABINET.pac_id);
            }
            else if ((radioButton2.Checked == true))
            {
                cmd_historia = string.Format("SELECT wiz.DATA_WIZYTY,wyk.RODZAJ_USLUGI, wyk.TRESC FROM wyk_uslugi wyk, wizyta wiz WHERE wyk.WIZ_ID=wiz.WIZ_ID and wiz.PAC_ID  = '{0}' order by wiz.DATA_WIZYTY", GABINET.pac_id);
            }
            DataTable Hist_Wiz = new DataTable();
            MySqlCommand cmd = new MySqlCommand(cmd_historia, r.con);
            MySqlDataReader czytnik = cmd.ExecuteReader();
            Hist_Wiz.Load(czytnik);
            return Hist_Wiz;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            Historia_Data_Grid_Wizyty();
        }
    }
}
