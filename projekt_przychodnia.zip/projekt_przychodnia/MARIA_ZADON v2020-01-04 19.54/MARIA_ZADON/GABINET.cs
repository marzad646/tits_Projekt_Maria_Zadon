﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MARIA_ZADON
{
    public partial class GABINET : Form
    {
        public string cmd_szukaj_wizyty;
        public string podaj_dzien_przyjecia;
        public static string pac_id;
        public static string wiz_id;
        public int numer_wiersza_w_datagrid_pacjenci;
        public int numer_wiersza_w_datagrid_icd;
        private string imiona;
        private string nazwisko;
        private string pesel;
        public string Rok;
        public string Rok2;
        public string Miesiac;
        public string Dzien;
        public string PP;
        public string data_urodzenia;
        public string plec;
        public string wiek;
        public string opis_badania;
        public string zalecenia;
        public string cmd_zapisz_wizyte;
        public string cmd_przyjecie;
        public string cmd_lista_kodow_ICD;
        public string cmd_przywolanie;
        public string wyszukaj_kod_icd;
        public string kod_icd_wpisz;

        REJESTRACJA r = new REJESTRACJA();
       


        public GABINET()
        {
            InitializeComponent();
            Data_Grid_Wizyty();
            ukrywanie_pol();
            
        }

        public void ukrywanie_pol()
        {
            label_nazwisko_imiona.Visible = false;
            label_pesel.Visible = false;
            label_data_urodzenia.Visible = false;
            label_wiek.Visible = false;
            label_plec.Visible = false;


        }

        public void Data_Grid_Wizyty()
        {
            dataGridView1.DataSource = Lista_Wizyt();
        }

        private DataTable Lista_Wizyt()
        {
            podaj_dzien_przyjecia = dzien_przyjęcia.Value.ToShortDateString();
            cmd_szukaj_wizyty = string.Format("SELECT DATE_FORMAT(wiz.godz_rozp,  \"%H:%i\") as START, DATE_FORMAT(wiz.godz_zak,  \"%H:%i\")  as STOP, pac.NAZWISKO, pac.IMIONA, pac.PESEL, pac.PAC_ID, WIZ_ID  FROM `wizyta` wiz, `pacjent` pac where wiz.pac_id=pac.pac_id and status = 'P' and DATA_WIZYTY = '{0}' order by wiz.godz_rozp;", podaj_dzien_przyjecia);
            DataTable Wizyty = new DataTable();
            MySqlCommand cmd = new MySqlCommand(cmd_szukaj_wizyty, r.con);
            MySqlDataReader czytnik = cmd.ExecuteReader();
            Wizyty.Load(czytnik);
            return Wizyty;
            
        }

        public void Data_Grid_Kod_ICD()
        {
            dataGridView2.DataSource = Lista_Kodow_ICD();
        }

        private DataTable Lista_Kodow_ICD()
        {
            wyszukaj_kod_icd = textBox_kod_icd.Text.ToUpper();
            cmd_lista_kodow_ICD = string.Format("SELECT KOD_ICD, NAZWA_ICD FROM `slownik_icd` where upper(KOD_ICD) LIKE '%{0}%' or upper(NAZWA_ICD) LIKE '%{1}%';", wyszukaj_kod_icd, wyszukaj_kod_icd);
            DataTable Kody_ICD = new DataTable();
            MySqlCommand cmd_ICD = new MySqlCommand(cmd_lista_kodow_ICD, r.con);
            MySqlDataReader czytnik_ICD = cmd_ICD.ExecuteReader();
            Kody_ICD.Load(czytnik_ICD);
            return Kody_ICD;

        }

        public void Pobranie_danych_z_DataGrid()
        {
            numer_wiersza_w_datagrid_pacjenci = Convert.ToInt32(dataGridView1.CurrentRow.Index);
            nazwisko = dataGridView1.Rows[numer_wiersza_w_datagrid_pacjenci].Cells[2].Value.ToString();
            imiona = dataGridView1.Rows[numer_wiersza_w_datagrid_pacjenci].Cells[3].Value.ToString();
            pesel = dataGridView1.Rows[numer_wiersza_w_datagrid_pacjenci].Cells[4].Value.ToString();
            pac_id = dataGridView1.Rows[numer_wiersza_w_datagrid_pacjenci].Cells[5].Value.ToString();
            wiz_id = dataGridView1.Rows[numer_wiersza_w_datagrid_pacjenci].Cells[6].Value.ToString();

        }
        public void Pobranie_danych_z_DataGrid_ICD()
        {
            numer_wiersza_w_datagrid_icd= Convert.ToInt32(dataGridView2.CurrentRow.Index);
            kod_icd_wpisz = dataGridView2.Rows[numer_wiersza_w_datagrid_icd].Cells[0].Value.ToString();
        }
        public void Metoda_Data_Urodzenia()
        {
            Rok = pesel.Substring(0, 2);
            Miesiac = pesel.Substring(2, 2);
            Dzien = pesel.Substring(4, 2);
            if (int.Parse(Miesiac) <= 12)
            {
                Rok2 = "19" + Rok;
            }
            else
            {
                Rok2 = "20" + Rok;
                Miesiac = (int.Parse(Miesiac.Substring(0, 1)) - 2).ToString() + Miesiac.Substring(1, 1);
            }
            data_urodzenia = Rok2 + "-" + Miesiac + "-" + Dzien;

        }
        public void Metoda_Plec()
        {
            PP = pesel.Substring(9, 1);
            if (PP == "0" || PP == "2" || PP == "4" || PP == "6" || PP == "8")
            {
                plec = "K";
            }
            else
            {
                plec = "M";
            }
        }

            public void wczytanie_danych_pacjenta()
        {
            label_pesel.Visible = true;
            label_nazwisko_imiona.Visible = true;
            label_plec.Visible = true;
            label_data_urodzenia.Visible = true;
            label_wiek.Visible = true;
            label_pesel.Text = pesel;
            label_nazwisko_imiona.Text = nazwisko+" "+imiona;
            label_plec.Text = plec;
            label_data_urodzenia.Text = data_urodzenia;
            label_wiek.Text = wiek;


        }

        public void zakoncz_wizyte()
        {
            opis_badania = textBox_opis_badania.Text;
            zalecenia = textBox_zalecenia.Text;
            cmd_zapisz_wizyte = string.Format("UPDATE `wizyta` SET OPIS_BAD = '{0}', ZALEC = '{1}', STATUS = 'Z', ROZP_CHOR = '{2}' where WIZ_ID = '{3}';", opis_badania, zalecenia, kod_icd_wpisz, wiz_id);
            MySqlCommand cmd_zw = new MySqlCommand(cmd_zapisz_wizyte, r.con);
            cmd_zw.ExecuteNonQuery();

        }
        private void button1_Click(object sender, EventArgs e)
        {
            Data_Grid_Wizyty();
        }

        public void przyjecie()
        {
            cmd_przyjecie = string.Format("UPDATE `wizyta` SET STATUS = 'R' where WIZ_ID = '{0}';", wiz_id);
            MySqlCommand cmd_prz = new MySqlCommand(cmd_przyjecie, r.con);
            cmd_prz.ExecuteNonQuery();
        }

        public void przywolanie()
        {
            cmd_przywolanie = string.Format("UPDATE `wizyta` SET STATUS = 'W' where WIZ_ID = '{0}';", wiz_id);
            MySqlCommand cmd_wez = new MySqlCommand(cmd_przywolanie, r.con);
            cmd_wez.ExecuteNonQuery();
        }
        public void czyszczenie_text_box()
        {
            textBox_kod_icd.Text = "";
            textBox_opis_badania.Text = "";
            textBox_zalecenia.Text = "";
            Data_Grid_Wizyty();
            Data_Grid_Kod_ICD();
        }
       

        private void button1_zakoncz_wizyte(object sender, EventArgs e)
        {
            Pobranie_danych_z_DataGrid_ICD();
            zakoncz_wizyte();
            czyszczenie_text_box();
            
        }

        private void button_szukaj_kodu_ICD_Click(object sender, EventArgs e)
        {
            Data_Grid_Kod_ICD();
        }

        private void button_przyjmij_Click(object sender, EventArgs e)
        {
            przyjecie();
            Metoda_Data_Urodzenia();
            Metoda_Plec();
            wczytanie_danych_pacjenta();
        }
        private void button_przywołaj_Click(object sender, EventArgs e)
        {
            Pobranie_danych_z_DataGrid();
            przywolanie();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            KONSULTACJE Otwrzorz_Konsultacje = new KONSULTACJE();
            Otwrzorz_Konsultacje.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            HISTORIA Otwórz_Historie = new HISTORIA();
            Otwórz_Historie.Show();
        }
    }
}
