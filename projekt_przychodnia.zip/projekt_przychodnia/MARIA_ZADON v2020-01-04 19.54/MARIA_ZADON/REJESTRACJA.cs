﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;


namespace MARIA_ZADON
{
    public partial class REJESTRACJA : Form
    {
        public string connection_string;
        public string adres_serwera;
        public MySqlConnection con;
        public string nazwa_bazy_danych;
        public string uzytkownik_bazy_danych;
        public string haslo_uzytkownika;
        public string port;
        public string imiona;
        public string nazwisko;
        public string pesel;
        public string cmd_szukaj;
        public string cmd_terminy;
        public string cmd_dodaj;
        public string cmd_planuj_wizyte;
        public string cmd_planuj_wizyte2;
        public string dodaj_imiona;
        public string dodaj_nazwisko;
        public string dodaj_pesel;
        public string dodaj_miasto;
        public string dodaj_kod_poczty;
        public string dodaj_ulice;
        public string dodaj_nr_budynku;
        public string dodaj_nr_lokalu;
        public string dodaj_nr_telefonu;
        public int numer_wiersza_w_datagrid_pacjenci;
        public int numer_wiersza_w_data_grid_terminy;
        public string pac_id;
        public string szukaj_dni_od;
        public string szukaj_dni_do;
        public string szukaj_godziny_od;
        public string szukaj_godziny_do;
        public string wyszukaj_wolny_termin;
        public string data_wizyty;
        public string godzina_rozp_wizyty;
        public string godzina_zak_wizyty;
        public string Brak_Nazwiska;
        public string Brak_Imienia;
        public string Brak_Pesel;
        public string Brak_Miasta;
        public string Brak_Kodu_Pocztowego;
        public string Brak_Ulicy;
        public string Brak_Numeru_Domu;
        public string Brak_Numeru_Lokalu;
        public string Brak_Numeru_Telefonu;
        public bool Czy_Zapisac;


        public REJESTRACJA()
        {
            InitializeComponent();
            ustawienia_data_time_pikcer();
            Ustawienia_Polaczenia();
            Polaczenie();
        }

        public void ustawienia_data_time_pikcer()
        {
            zakres_godzin_od.Format = DateTimePickerFormat.Custom;
            zakres_godzin_od.CustomFormat = "HH:mm";
            zakres_godzin_od.ShowUpDown = true;
            zakres_godzin_do.Format = DateTimePickerFormat.Custom;
            zakres_godzin_do.CustomFormat = "HH:mm";
            zakres_godzin_do.ShowUpDown = true;
        }

        public void Data_Grid_Uzupelnij()
        {
            dataGridView1.DataSource = Lista_Pacjentow();
        }
        private DataTable Lista_Pacjentow()
        {

            DataTable Pacjenci = new DataTable();
            MySqlCommand cmd = new MySqlCommand(cmd_szukaj, con);
            MySqlDataReader czytnik = cmd.ExecuteReader();
            Pacjenci.Load(czytnik);
            return Pacjenci;

        }


        public void Ustawienia_Polaczenia()
        {
            StreamReader SR = new StreamReader("USTAWIENIA_POŁĄCZENIA.txt");
            adres_serwera = SR.ReadLine();
            port = SR.ReadLine();
            nazwa_bazy_danych = SR.ReadLine();
            uzytkownik_bazy_danych = SR.ReadLine();
            haslo_uzytkownika = SR.ReadLine();
            SR.Close();
        }
        public void Polaczenie()
        {

            connection_string = string.Format("server={0}; port={1}; database={2}; user={3}; password={4};", adres_serwera, port, nazwa_bazy_danych, uzytkownik_bazy_danych, haslo_uzytkownika);
            con = new MySqlConnection(connection_string);
            con.Open();


        }
        public void Wyszukaj_Pacjenta()
        {
            imiona = TEXT_BOX_IMIONA.Text.ToUpper();
            nazwisko = TEXT_BOX_NAZWISKO.Text.ToUpper();
            pesel = TEXT_BOX_PESEL.Text.ToUpper();
            cmd_szukaj = string.Format("SELECT * FROM `pacjent` WHERE IMIONA LIKE '{0}' OR `NAZWISKO` LIKE '{1}' OR `PESEL` LIKE '{2}' ", imiona, nazwisko, pesel);


        }
        public void Dodaj_Pacjenta()
        {
            dodaj_nazwisko = TEXT_BOX_DODAJ_NAZWISKO.Text.ToUpper();
            dodaj_imiona = TEXT_BOX_DODAJ_IMIE.Text.ToUpper();
            dodaj_pesel = TEXT_BOX_DODAJ_PESEL.Text.ToUpper();
            dodaj_miasto = TEXT_BOX_DODAJ_MIAST0.Text.ToUpper();
            dodaj_kod_poczty = TEXT_BOX_DODAJ_KOD_POCZTOWY.Text.ToUpper();
            dodaj_ulice = TEXT_BOX_DODAJ_ULICE.Text.ToUpper();
            dodaj_nr_budynku = TEXT_BOX_DODAJ_NR_BUD.Text.ToUpper();
            dodaj_nr_lokalu = TEXT_BOX_DODAJ_NR_LOK.Text.ToUpper();
            dodaj_nr_telefonu = TEXT_BOX_DODAJ_NR_TELEFONU.Text.ToUpper();
            cmd_dodaj = string.Format("INSERT INTO `pacjent` (`PAC_ID`, `NAZWISKO`, `IMIONA`, `PESEL`, `MIASTO`, `KOD_POCZT`, `ULICA`, `NR_BUD`, `NR_LOK`, `NR_TELEFONU`) VALUES((SELECT MAX(PAC_ID)+1 FROM `pacjent` pac), '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}');", dodaj_nazwisko, dodaj_imiona, dodaj_pesel, dodaj_miasto, dodaj_kod_poczty, dodaj_ulice, dodaj_nr_budynku, dodaj_nr_lokalu, dodaj_nr_telefonu);
            MySqlCommand cmd2 = new MySqlCommand(cmd_dodaj, con);
            cmd2.ExecuteNonQuery();
        }
        public void Pobranie_danych_z_DataGrid()
        {
            numer_wiersza_w_datagrid_pacjenci = Convert.ToInt32(dataGridView1.CurrentRow.Index);
            pac_id = dataGridView1.Rows[numer_wiersza_w_datagrid_pacjenci].Cells[0].Value.ToString();

        }
        public void Pobranie_Danych_Terminu_Wizyty_Z_DataGrid()
        {
            numer_wiersza_w_data_grid_terminy = Convert.ToInt32(dataGridView2.CurrentRow.Index);
            data_wizyty = dataGridView2.Rows[numer_wiersza_w_data_grid_terminy].Cells[0].Value.ToString();
            godzina_rozp_wizyty = dataGridView2.Rows[numer_wiersza_w_data_grid_terminy].Cells[1].Value.ToString();
            godzina_zak_wizyty = dataGridView2.Rows[numer_wiersza_w_data_grid_terminy].Cells[2].Value.ToString();

        }

        public void Planowanie_Wizyty()
        {
            cmd_planuj_wizyte = string.Format("INSERT INTO `wizyta` (`PAC_ID`, `WIZ_ID`, `DATA_WIZYTY`, `GODZ_ROZP`, `GODZ_ZAK`, `STATUS`, `ROZP_CHOR`, `OPIS_BAD`, `ZALEC`) VALUES('{0}', (SELECT MAX(WIZ_ID)+1 FROM `wizyta` wiz), '{1}', '{2}', '{3}', 'P', '', '', '');", pac_id, data_wizyty, godzina_rozp_wizyty, godzina_zak_wizyty);
            MySqlCommand cmd2 = new MySqlCommand(cmd_planuj_wizyte, con);
            cmd2.ExecuteNonQuery();
            cmd_planuj_wizyte2 = string.Format("update terminarz set CZY_WOLNY = 'N' where DATA = '{0}' and GODZ_ROZP = '{1}' and GODZ_ZAK = '{2}';", data_wizyty, godzina_rozp_wizyty, godzina_zak_wizyty);
            MySqlCommand cmd3 = new MySqlCommand(cmd_planuj_wizyte2, con);
            cmd3.ExecuteNonQuery();
        }


        public void szukaj_terminu_wizyty()
        {
            szukaj_dni_od = zakres_dni_od.Value.ToShortDateString();
            szukaj_dni_do = zakres_dni_do.Value.ToShortDateString();
            szukaj_godziny_od = zakres_godzin_od.Value.ToShortTimeString();
            szukaj_godziny_do = zakres_godzin_do.Value.ToShortTimeString();
            cmd_terminy = string.Format("select * from terminarz where DATA BETWEEN '{0}' AND '{1}' AND GODZ_ROZP >= '{2}' AND GODZ_ZAK <= '{3}' AND CZY_WOLNY = 'T';", szukaj_dni_od, szukaj_dni_do, szukaj_godziny_od, szukaj_godziny_do);

        }

        public void szukaj_pierwszego_wolnego_terminu()
        {
            cmd_terminy = string.Format("SELECT * FROM `terminarz` WHERE DATA in (select MIN(data) from terminarz where data>=DATE_FORMAT(sysdate(),  \"%Y-%m-%d\") and  CZY_WOLNY = 'T') and GODZ_ROZP in (select min(GODZ_ROZP) from terminarz where CZY_WOLNY = 'T' and DATA in (select MIN(data) from terminarz where data>=DATE_FORMAT(sysdate(),  \"%Y-%m-%d\") and CZY_WOLNY = 'T'));");
        }

        public void Data_Grid_Wolne_Terminy()
        {
            dataGridView2.DataSource = Lista_Terminow();
        }
        private DataTable Lista_Terminow()
        {

            DataTable Terminy = new DataTable();
            MySqlCommand cmd = new MySqlCommand(cmd_terminy, con);
            MySqlDataReader czytnik_terminy = cmd.ExecuteReader();
            Terminy.Load(czytnik_terminy);
            return Terminy;

        }
        private void BUTTON_SZUKAJ_PACJENTA_Click(object sender, EventArgs e)
        {
            Wyszukaj_Pacjenta();
            Data_Grid_Uzupelnij();

        }

        private void BUTTON_ZAPISZ_Click(object sender, EventArgs e)
        {
            Czy_Zapisac = true;
            sprawdzenie();
            if (Czy_Zapisac == true)
            {
                Dodaj_Pacjenta();
                MessageBox.Show("Dane zostały poprawnie zapisane");
                Czyszczenie_Text_Box_Z_Danymi_Pacjeta();
            }
            else
            {
                MessageBox.Show(Brak_Nazwiska+Brak_Imienia+Brak_Pesel+Brak_Miasta+Brak_Kodu_Pocztowego+Brak_Ulicy+Brak_Numeru_Domu+Brak_Numeru_Lokalu+Brak_Numeru_Telefonu);
            }
            
            
        }

        private void BUTTON_ZAREJESTRUJ_Click(object sender, EventArgs e)
        {
            Pobranie_danych_z_DataGrid();
            Pobranie_Danych_Terminu_Wizyty_Z_DataGrid();
            Planowanie_Wizyty();

        }

        private void button_wyszukaj_termin_Click(object sender, EventArgs e)
        {
            szukaj_terminu_wizyty();
            Data_Grid_Wolne_Terminy();
        }

        private void button_pierwszy_wolny_Click(object sender, EventArgs e)
        {
            szukaj_pierwszego_wolnego_terminu();
            Data_Grid_Wolne_Terminy();
        }

        private void TEXT_BOX_DODAJ_PESEL_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == 8)// Sprawdzamy czy wciśnięty jest liczbą albo klawiszem backspace
            {
                e.Handled = false;                                     // Nie blokujemy znaku
            }
            else
            {
                e.Handled = true;
            }
        }

        private void TEXT_BOX_DODAJ_IMIE_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122 || e.KeyChar == 8 || e.KeyChar == 32 || e.KeyChar == 260 || e.KeyChar == 262 || e.KeyChar == 280
               || e.KeyChar == 321 || e.KeyChar == 323 || e.KeyChar == 211 || e.KeyChar == 346 || e.KeyChar == 377 || e.KeyChar == 379 || e.KeyChar == 261 || e.KeyChar == 263 
               || e.KeyChar == 281 || e.KeyChar == 322 || e.KeyChar == 324 || e.KeyChar == 243 || e.KeyChar == 347 || e.KeyChar == 378 || e.KeyChar == 380)
            {
                e.Handled = false;                                     
            }
            else
            {
                e.Handled = true;
            }
        }

        private void TEXT_BOX_DODAJ_NAZWISKO_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122 || e.KeyChar == 8 || e.KeyChar == 32 || e.KeyChar == 260 || e.KeyChar == 262 || e.KeyChar == 280
              || e.KeyChar == 321 || e.KeyChar == 323 || e.KeyChar == 211 || e.KeyChar == 346 || e.KeyChar == 377 || e.KeyChar == 379 || e.KeyChar == 261 || e.KeyChar == 263
              || e.KeyChar == 281 || e.KeyChar == 322 || e.KeyChar == 324 || e.KeyChar == 243 || e.KeyChar == 347 || e.KeyChar == 378 || e.KeyChar == 380)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void TEXT_BOX_DODAJ_KOD_POCZTOWY_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == 8 || e.KeyChar == 45)// Sprawdzamy czy wciśnięty jest liczbą albo klawiszem backspace
            {
                e.Handled = false;                                     // Nie blokujemy znaku
            }
            else
            {
                e.Handled = true;
            }
        }

        private void TEXT_BOX_DODAJ_MIAST0_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122 || e.KeyChar == 8 || e.KeyChar == 32 || e.KeyChar == 260 || e.KeyChar == 262 || e.KeyChar == 280
            || e.KeyChar == 321 || e.KeyChar == 323 || e.KeyChar == 211 || e.KeyChar == 346 || e.KeyChar == 377 || e.KeyChar == 379 || e.KeyChar == 261 || e.KeyChar == 263
            || e.KeyChar == 281 || e.KeyChar == 322 || e.KeyChar == 324 || e.KeyChar == 243 || e.KeyChar == 347 || e.KeyChar == 378 || e.KeyChar == 380)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void TEXT_BOX_DODAJ_ULICE_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122 || e.KeyChar == 8 || e.KeyChar == 32 || e.KeyChar == 260 || e.KeyChar == 262 || e.KeyChar == 280
            || e.KeyChar == 321 || e.KeyChar == 323 || e.KeyChar == 211 || e.KeyChar == 346 || e.KeyChar == 377 || e.KeyChar == 379 || e.KeyChar == 261 || e.KeyChar == 263
            || e.KeyChar == 281 || e.KeyChar == 322 || e.KeyChar == 324 || e.KeyChar == 243 || e.KeyChar == 347 || e.KeyChar == 378 || e.KeyChar == 380)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void TEXT_BOX_DODAJ_NR_BUD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == 8)// Sprawdzamy czy wciśnięty jest liczbą albo klawiszem backspace
            {
                e.Handled = false;                                     // Nie blokujemy znaku
            }
            else
            {
                e.Handled = true;
            }
        }

        private void TEXT_BOX_DODAJ_NR_LOK_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == 8)// Sprawdzamy czy wciśnięty jest liczbą albo klawiszem backspace
            {
                e.Handled = false;                                     // Nie blokujemy znaku
            }
            else
            {
                e.Handled = true;
            }
        }

        private void TEXT_BOX_DODAJ_NR_TELEFONU_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == 8 || e.KeyChar == 45)// Sprawdzamy czy wciśnięty jest liczbą albo klawiszem backspace
            {
                e.Handled = false;                                     // Nie blokujemy znaku
            }
            else
            {
                e.Handled = true;
            }
        }
        public void sprawdzenie()
        {
            Brak_Nazwiska = "";
            Brak_Imienia = "";
            Brak_Pesel = "";
            Brak_Miasta = "";
            Brak_Kodu_Pocztowego = "";
            Brak_Ulicy = "";
            Brak_Numeru_Domu = "";
            Brak_Numeru_Lokalu = "";
            Brak_Numeru_Telefonu = "";
            if (TEXT_BOX_DODAJ_NAZWISKO.Text == "") { Brak_Nazwiska = "Nie wprowadzono nazwiska pacjęta!\n";  Czy_Zapisac = false; }
            if (TEXT_BOX_DODAJ_IMIE.Text == "") { Brak_Imienia = "Nie wprowadzono imienia pacjęta!\n"; Czy_Zapisac = false; }
            if (TEXT_BOX_DODAJ_PESEL.Text.Length < 11) { Brak_Pesel = "Nie poprawna wartość w polu pesel!\n"; Czy_Zapisac = false; }
            if (TEXT_BOX_DODAJ_MIAST0.Text == "") { Brak_Miasta = "Nie wprowadzono nazwy miasta!\n"; Czy_Zapisac = false; }
            if (TEXT_BOX_DODAJ_KOD_POCZTOWY.Text == "") { Brak_Kodu_Pocztowego = "Nie wprowadzono kodu pocztowego!\n"; Czy_Zapisac = false; }
            if (TEXT_BOX_DODAJ_ULICE.Text == "") {Brak_Ulicy = "Nie wprowadzono nazwy ulicy!\n"; Czy_Zapisac = false; }
            if (TEXT_BOX_DODAJ_NR_BUD.Text == "") { Brak_Numeru_Domu = "Nie wprowadzono numeru budynku!\n"; Czy_Zapisac = false; }
            if (TEXT_BOX_DODAJ_NR_LOK.Text == "") {Brak_Numeru_Lokalu = "Nie wprowadzono numeru lokalu!\n"; Czy_Zapisac = false; }
            if (TEXT_BOX_DODAJ_NR_TELEFONU.Text == "") { Brak_Numeru_Telefonu = "Nie wprowadzono numeru telefony!\n"; Czy_Zapisac = false; }
        }
        public void Czyszczenie_Text_Box_Z_Danymi_Pacjeta()
        {
            TEXT_BOX_DODAJ_NAZWISKO.Text = "";
            TEXT_BOX_DODAJ_IMIE.Text = "";
            TEXT_BOX_DODAJ_PESEL.Text = "";
            TEXT_BOX_DODAJ_MIAST0.Text = "";
            TEXT_BOX_DODAJ_KOD_POCZTOWY.Text = "";
            TEXT_BOX_DODAJ_ULICE.Text = "";
            TEXT_BOX_DODAJ_NR_BUD.Text = "";
            TEXT_BOX_DODAJ_NR_LOK.Text = "";
            TEXT_BOX_DODAJ_NR_TELEFONU.Text = "";
        }
    }

}
