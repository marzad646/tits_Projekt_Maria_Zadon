﻿namespace MARIA_ZADON
{
    partial class PANEL_ADMINISTRACYJNY
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.TEXT_BOX_PASS = new System.Windows.Forms.TextBox();
            this.TEXT_BOX_USER = new System.Windows.Forms.TextBox();
            this.TEXT_BOX_SID = new System.Windows.Forms.TextBox();
            this.TEXT_BOX_PORT = new System.Windows.Forms.TextBox();
            this.TEXT_BOX_ADRES = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.slot = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.DATA_DO = new System.Windows.Forms.DateTimePicker();
            this.DATA_OD = new System.Windows.Forms.DateTimePicker();
            this.GODZINY_ZAK = new System.Windows.Forms.DateTimePicker();
            this.GODZINY_ROZP = new System.Windows.Forms.DateTimePicker();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Black;
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.TEXT_BOX_PASS);
            this.groupBox1.Controls.Add(this.TEXT_BOX_USER);
            this.groupBox1.Controls.Add(this.TEXT_BOX_SID);
            this.groupBox1.Controls.Add(this.TEXT_BOX_PORT);
            this.groupBox1.Controls.Add(this.TEXT_BOX_ADRES);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox1.ForeColor = System.Drawing.Color.Lime;
            this.groupBox1.Location = new System.Drawing.Point(33, 43);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 428);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "POŁĄCZENIE";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(41, 375);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 38);
            this.button1.TabIndex = 10;
            this.button1.Text = "ZAPISZ";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // TEXT_BOX_PASS
            // 
            this.TEXT_BOX_PASS.Location = new System.Drawing.Point(20, 330);
            this.TEXT_BOX_PASS.Name = "TEXT_BOX_PASS";
            this.TEXT_BOX_PASS.Size = new System.Drawing.Size(100, 20);
            this.TEXT_BOX_PASS.TabIndex = 9;
            // 
            // TEXT_BOX_USER
            // 
            this.TEXT_BOX_USER.Location = new System.Drawing.Point(20, 259);
            this.TEXT_BOX_USER.Name = "TEXT_BOX_USER";
            this.TEXT_BOX_USER.Size = new System.Drawing.Size(100, 20);
            this.TEXT_BOX_USER.TabIndex = 8;
            // 
            // TEXT_BOX_SID
            // 
            this.TEXT_BOX_SID.Location = new System.Drawing.Point(20, 189);
            this.TEXT_BOX_SID.Name = "TEXT_BOX_SID";
            this.TEXT_BOX_SID.Size = new System.Drawing.Size(100, 20);
            this.TEXT_BOX_SID.TabIndex = 7;
            // 
            // TEXT_BOX_PORT
            // 
            this.TEXT_BOX_PORT.Location = new System.Drawing.Point(20, 130);
            this.TEXT_BOX_PORT.Name = "TEXT_BOX_PORT";
            this.TEXT_BOX_PORT.Size = new System.Drawing.Size(100, 20);
            this.TEXT_BOX_PORT.TabIndex = 6;
            // 
            // TEXT_BOX_ADRES
            // 
            this.TEXT_BOX_ADRES.Location = new System.Drawing.Point(20, 70);
            this.TEXT_BOX_ADRES.Name = "TEXT_BOX_ADRES";
            this.TEXT_BOX_ADRES.Size = new System.Drawing.Size(100, 20);
            this.TEXT_BOX_ADRES.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 301);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "PASS:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 228);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "USER:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "SID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "PORT:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ADRES:";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Black;
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.slot);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.DATA_DO);
            this.groupBox2.Controls.Add(this.DATA_OD);
            this.groupBox2.Controls.Add(this.GODZINY_ZAK);
            this.groupBox2.Controls.Add(this.GODZINY_ROZP);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox2.ForeColor = System.Drawing.Color.Lime;
            this.groupBox2.Location = new System.Drawing.Point(259, 43);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(273, 363);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "TERMINARZ";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(77, 278);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 58);
            this.button2.TabIndex = 10;
            this.button2.Text = "GENERUJ";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(30, 214);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(157, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "CZAS TRWANIA WIZYTY:";
            // 
            // slot
            // 
            this.slot.FormattingEnabled = true;
            this.slot.Items.AddRange(new object[] {
            "10",
            "15",
            "20",
            "30"});
            this.slot.Location = new System.Drawing.Point(33, 230);
            this.slot.Name = "slot";
            this.slot.Size = new System.Drawing.Size(121, 21);
            this.slot.TabIndex = 8;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(160, 158);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "DO:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(30, 161);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "OD:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(30, 105);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "DZIEŃ DO:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(30, 43);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "DZIEŃ OD:";
            // 
            // DATA_DO
            // 
            this.DATA_DO.Location = new System.Drawing.Point(33, 127);
            this.DATA_DO.Name = "DATA_DO";
            this.DATA_DO.Size = new System.Drawing.Size(200, 20);
            this.DATA_DO.TabIndex = 3;
            // 
            // DATA_OD
            // 
            this.DATA_OD.Location = new System.Drawing.Point(33, 69);
            this.DATA_OD.Name = "DATA_OD";
            this.DATA_OD.Size = new System.Drawing.Size(200, 20);
            this.DATA_OD.TabIndex = 2;
            // 
            // GODZINY_ZAK
            // 
            this.GODZINY_ZAK.Location = new System.Drawing.Point(160, 177);
            this.GODZINY_ZAK.Name = "GODZINY_ZAK";
            this.GODZINY_ZAK.Size = new System.Drawing.Size(73, 20);
            this.GODZINY_ZAK.TabIndex = 1;
            this.GODZINY_ZAK.Value = new System.DateTime(2019, 11, 3, 16, 0, 0, 0);
            // 
            // GODZINY_ROZP
            // 
            this.GODZINY_ROZP.Location = new System.Drawing.Point(33, 177);
            this.GODZINY_ROZP.Name = "GODZINY_ROZP";
            this.GODZINY_ROZP.Size = new System.Drawing.Size(73, 20);
            this.GODZINY_ROZP.TabIndex = 0;
            this.GODZINY_ROZP.Value = new System.DateTime(2019, 11, 3, 8, 0, 0, 0);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(23, 105);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(156, 23);
            this.progressBar1.TabIndex = 4;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button3);
            this.groupBox3.Controls.Add(this.progressBar1);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox3.ForeColor = System.Drawing.Color.Lime;
            this.groupBox3.Location = new System.Drawing.Point(560, 43);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 147);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "IMPORT ICD";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(45, 33);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(111, 56);
            this.button3.TabIndex = 6;
            this.button3.Text = "IMPORTUJ ICD";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // PANEL_ADMINISTRACYJNY
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1264, 682);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "PANEL_ADMINISTRACYJNY";
            this.Text = "PANEL_ADMINISTRACYJNY";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TEXT_BOX_PASS;
        private System.Windows.Forms.TextBox TEXT_BOX_USER;
        private System.Windows.Forms.TextBox TEXT_BOX_SID;
        private System.Windows.Forms.TextBox TEXT_BOX_PORT;
        private System.Windows.Forms.TextBox TEXT_BOX_ADRES;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DateTimePicker GODZINY_ROZP;
        private System.Windows.Forms.DateTimePicker GODZINY_ZAK;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker DATA_DO;
        private System.Windows.Forms.DateTimePicker DATA_OD;
        private System.Windows.Forms.ComboBox slot;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button3;
    }
}