﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Globalization;
using MySql.Data.MySqlClient;
using Excel = Microsoft.Office.Interop.Excel;

namespace MARIA_ZADON
{
    public partial class PANEL_ADMINISTRACYJNY : Form
    {
        public string adres_serwera;
        public string port;
        public string nazwa_bazy_danych;
        public string uzytkownik_bazy_danych;
        public string haslo_uzytkownika;
        public string godziny_od_string;
        public string godziny_do_string;
        public string data_od_string;
        public string data_do_string;
        public int godzina_od;
        public int minuty_od;
        public int dzien_od;
        public int miesiac_od;
        public int rok_od;
        public int godzina_do;
        public int minuty_do;
        public int dzien_do;
        public int miesiac_do;
        public int rok_do;
        public int dzien_licznik;
        public int godziny_roznica;
        public int minuty_roznica;
        public string time_span_godziny_string;
        public double wizyty_licznik;
        public int slot_czasowy;
        public int time_span_dni_int;

        //zmienne do importu slownika ICD
        public string kod_icd;
        public string nazwa_icd;
        public int wiersz;
        public string insert_icd;

        Excel.Application AplikacjaXls;
        Excel.Workbook DokumentXls;
        Excel.Worksheet ArkuszXls;
        Excel.Range range;
       


        //budowanie insert into terminarz
        public string insert_terminarz;
        public string godzina_rozpoczecia;
        public string godzina_zakonczenia;
        public string data_wizyty;



        public PANEL_ADMINISTRACYJNY()
        {
            InitializeComponent();
            Odczyt_Ustawień();
            ustawienia_data_time_pikcer();
            progressBar1.Visible = false;

        }

        public void Odczyt_Ustawień()
        {
            StreamReader SR = new StreamReader("USTAWIENIA_POŁĄCZENIA.txt");
            TEXT_BOX_ADRES.Text = SR.ReadLine();
            TEXT_BOX_PORT.Text = SR.ReadLine();
            TEXT_BOX_SID.Text = SR.ReadLine();
            TEXT_BOX_USER.Text = SR.ReadLine();
            TEXT_BOX_PASS.Text = SR.ReadLine();
            SR.Close();
        }
        public void Zapis_Ustaiweń()
        {
            adres_serwera = TEXT_BOX_ADRES.Text;
            port = TEXT_BOX_PORT.Text;
            nazwa_bazy_danych = TEXT_BOX_SID.Text;
            uzytkownik_bazy_danych = TEXT_BOX_USER.Text;
            haslo_uzytkownika = TEXT_BOX_PASS.Text;

            ;
            StreamWriter sw = new StreamWriter("USTAWIENIA_POŁĄCZENIA.txt");
            sw.WriteLine(adres_serwera);
            sw.WriteLine(port);
            sw.WriteLine(nazwa_bazy_danych);
            sw.WriteLine(uzytkownik_bazy_danych);
            sw.WriteLine(haslo_uzytkownika);
            sw.Close();
        }
        public void ustawienia_data_time_pikcer()
        {
            GODZINY_ROZP.Format = DateTimePickerFormat.Custom;
            GODZINY_ROZP.CustomFormat = "HH:mm";
            GODZINY_ROZP.ShowUpDown = true;
            GODZINY_ZAK.Format = DateTimePickerFormat.Custom;
            GODZINY_ZAK.CustomFormat = "HH:mm";
            GODZINY_ZAK.ShowUpDown = true;
        }


        public void generowanie_terminarza()
        {
            REJESTRACJA r = new REJESTRACJA();
            godziny_od_string = GODZINY_ROZP.Value.ToShortTimeString();
            data_od_string = DATA_OD.Value.ToShortDateString();

            godzina_od = int.Parse(godziny_od_string.Substring(0, 2));
            minuty_od = int.Parse(godziny_od_string.Substring(3, 2));
            dzien_od = int.Parse(data_od_string.Substring(8, 2));
            miesiac_od = int.Parse(data_od_string.Substring(5, 2));
            rok_od = int.Parse(data_od_string.Substring(0, 4));

            godziny_do_string = GODZINY_ZAK.Value.ToShortTimeString();
            data_do_string = DATA_DO.Value.ToShortDateString();
            godzina_do = int.Parse(godziny_do_string.Substring(0, 2));
            minuty_do = int.Parse(godziny_do_string.Substring(3, 2));
            dzien_do = int.Parse(data_do_string.Substring(8, 2));
            miesiac_do = int.Parse(data_do_string.Substring(5, 2));
            rok_do = int.Parse(data_do_string.Substring(0, 4));

            slot_czasowy = int.Parse(slot.Text);
            DateTime date_time_od = new DateTime(2999, 12, 31, godzina_od, minuty_od, 00);
            DateTime date_time_do = new DateTime(2999, 12, 31, godzina_do, minuty_do, 00);
            DateTime date_time_od_licznik = date_time_od;
            DateTime date_time_dzien_od = new DateTime(rok_od, miesiac_od, dzien_od, 00, 00, 00);
            DateTime date_time_dzien_do = new DateTime(rok_do, miesiac_do, dzien_do, 00, 00, 00);
            TimeSpan time_span_godziny = (date_time_do - date_time_od);
            TimeSpan time_span_dni = (date_time_dzien_do - date_time_dzien_od);
            time_span_godziny_string = time_span_godziny.ToString(@"hh\:mm");
            godziny_roznica = int.Parse(time_span_godziny_string.Substring(0, 2));
            minuty_roznica = int.Parse(time_span_godziny_string.Substring(3, 2));
            wizyty_licznik = (((godziny_roznica * 60) + minuty_roznica) / slot_czasowy);
            time_span_dni_int = int.Parse(time_span_dni.ToString(@"dd"));

            StreamWriter sw2 = new StreamWriter("GENEROWANIE_TERMINARZA.txt");
            for (dzien_licznik = 0; dzien_licznik < time_span_dni_int + 1; dzien_licznik++)
            {
                data_wizyty = date_time_dzien_od.ToString(@"yyyy\-MM\-dd");

                for (int i = 0; i < wizyty_licznik; i++)
                {

                    godzina_rozpoczecia = date_time_od_licznik.ToString(@"HH\:mm\:ss");
                    godzina_zakonczenia = date_time_od_licznik.AddMinutes(slot_czasowy).ToString(@"HH\:mm\:ss");
                    insert_terminarz = string.Format("INSERT INTO `terminarz` (`DATA`, `GODZ_ROZP`, `GODZ_ZAK`, `CZY_WOLNY`) VALUES ('{0}', '{1}', '{2}', '{3}');", data_wizyty, godzina_rozpoczecia, godzina_zakonczenia, "T");
                    MySqlCommand cmd = new MySqlCommand(insert_terminarz, r.con);
                    cmd.ExecuteNonQuery();
                    sw2.WriteLine(insert_terminarz);//testowo zapis insertów do pliku trzeba otworzyć połączenie i zapisać do bazy
                    date_time_od_licznik = date_time_od_licznik.AddMinutes(slot_czasowy);
                }

                date_time_od_licznik = date_time_od;
                date_time_dzien_od = date_time_dzien_od.AddDays(1);
            }
            sw2.Close();
        }

        public void wczytaj_kody_icd()
            {
            REJESTRACJA r = new REJESTRACJA();
            Stream myStream = null;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = "Pulpit";
            openFileDialog1.Filter = "txt files (*.xls)|*.xls|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                
                    if ((myStream = openFileDialog1.OpenFile()) != null)
                    {
                        using (myStream)
                        {
                            AplikacjaXls = new Excel.Application();
                            DokumentXls = AplikacjaXls.Workbooks.Open(openFileDialog1.FileName);
                            ArkuszXls = (Excel.Worksheet)DokumentXls.Worksheets.get_Item(1);
                            range = ArkuszXls.UsedRange;
                            progressBar1.Visible = true;
                            progressBar1.Maximum = range.Rows.Count;
                            progressBar1.Step = 1;


                            for (wiersz = 2; wiersz <= range.Rows.Count; wiersz++)
                            {
                                kod_icd = (range.Cells[wiersz, 1] as Excel.Range).Value2.ToString();
                                nazwa_icd = (range.Cells[wiersz, 2] as Excel.Range).Value2.ToString();
                                insert_icd = string.Format("INSERT INTO `slownik_icd` (`KOD_ICD`, `NAZWA_ICD`, `CZY_AKTYWNY`) VALUES('{0}', '{1}', 'A');",kod_icd,nazwa_icd);
                                MySqlCommand cmd_icd = new MySqlCommand(insert_icd, r.con);
                            try
                            {
                                cmd_icd.ExecuteNonQuery();
                            }
                            catch (Exception)
                            {

                                
                            }
                            
                                progressBar1.PerformStep();
                                
                            }
                            DokumentXls.Close(true, null, null);
                            AplikacjaXls.Quit();
                        progressBar1.Visible = false;
                            MessageBox.Show("Zaimportowano KODY ICD");


                    }
                    
                }
              }
            }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Zapis_Ustaiweń();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            generowanie_terminarza();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            wczytaj_kody_icd();
        }

    }
}
