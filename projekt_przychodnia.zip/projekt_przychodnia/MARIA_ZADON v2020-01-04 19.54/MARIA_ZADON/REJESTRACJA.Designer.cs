﻿namespace MARIA_ZADON
{
    partial class REJESTRACJA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BUTTON_ZAREJESTRUJ = new System.Windows.Forms.Button();
            this.BUTTON_SZUKAJ_PACJENTA = new System.Windows.Forms.Button();
            this.TEXT_BOX_PESEL = new System.Windows.Forms.TextBox();
            this.TEXT_BOX_NAZWISKO = new System.Windows.Forms.TextBox();
            this.TEXT_BOX_IMIONA = new System.Windows.Forms.TextBox();
            this.LABEL_PESEL = new System.Windows.Forms.Label();
            this.LABEL_NAZWISKO = new System.Windows.Forms.Label();
            this.LABEL_IMIONA = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.BUTTON_ZAPISZ = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TEXT_BOX_DODAJ_NR_TELEFONU = new System.Windows.Forms.TextBox();
            this.TEXT_BOX_DODAJ_NR_LOK = new System.Windows.Forms.TextBox();
            this.TEXT_BOX_DODAJ_NR_BUD = new System.Windows.Forms.TextBox();
            this.TEXT_BOX_DODAJ_ULICE = new System.Windows.Forms.TextBox();
            this.TEXT_BOX_DODAJ_KOD_POCZTOWY = new System.Windows.Forms.TextBox();
            this.TEXT_BOX_DODAJ_MIAST0 = new System.Windows.Forms.TextBox();
            this.TEXT_BOX_DODAJ_PESEL = new System.Windows.Forms.TextBox();
            this.TEXT_BOX_DODAJ_NAZWISKO = new System.Windows.Forms.TextBox();
            this.TEXT_BOX_DODAJ_IMIE = new System.Windows.Forms.TextBox();
            this.zakres_dni_od = new System.Windows.Forms.DateTimePicker();
            this.zakres_dni_do = new System.Windows.Forms.DateTimePicker();
            this.zakres_godzin_od = new System.Windows.Forms.DateTimePicker();
            this.zakres_godzin_do = new System.Windows.Forms.DateTimePicker();
            this.button_wyszukaj_termin = new System.Windows.Forms.Button();
            this.button_pierwszy_wolny = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BUTTON_SZUKAJ_PACJENTA);
            this.groupBox1.Controls.Add(this.TEXT_BOX_PESEL);
            this.groupBox1.Controls.Add(this.TEXT_BOX_NAZWISKO);
            this.groupBox1.Controls.Add(this.TEXT_BOX_IMIONA);
            this.groupBox1.Controls.Add(this.LABEL_PESEL);
            this.groupBox1.Controls.Add(this.LABEL_NAZWISKO);
            this.groupBox1.Controls.Add(this.LABEL_IMIONA);
            this.groupBox1.Location = new System.Drawing.Point(21, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1216, 95);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "WYSZUKAJ PACJENTA W SYSTEMIE";
            // 
            // BUTTON_ZAREJESTRUJ
            // 
            this.BUTTON_ZAREJESTRUJ.Location = new System.Drawing.Point(347, 636);
            this.BUTTON_ZAREJESTRUJ.Name = "BUTTON_ZAREJESTRUJ";
            this.BUTTON_ZAREJESTRUJ.Size = new System.Drawing.Size(200, 44);
            this.BUTTON_ZAREJESTRUJ.TabIndex = 7;
            this.BUTTON_ZAREJESTRUJ.Text = "ZAREJESTRUJ";
            this.BUTTON_ZAREJESTRUJ.UseVisualStyleBackColor = true;
            this.BUTTON_ZAREJESTRUJ.Click += new System.EventHandler(this.BUTTON_ZAREJESTRUJ_Click);
            // 
            // BUTTON_SZUKAJ_PACJENTA
            // 
            this.BUTTON_SZUKAJ_PACJENTA.Location = new System.Drawing.Point(427, 19);
            this.BUTTON_SZUKAJ_PACJENTA.Name = "BUTTON_SZUKAJ_PACJENTA";
            this.BUTTON_SZUKAJ_PACJENTA.Size = new System.Drawing.Size(113, 47);
            this.BUTTON_SZUKAJ_PACJENTA.TabIndex = 6;
            this.BUTTON_SZUKAJ_PACJENTA.Text = "SZUKAJ";
            this.BUTTON_SZUKAJ_PACJENTA.UseVisualStyleBackColor = true;
            this.BUTTON_SZUKAJ_PACJENTA.Click += new System.EventHandler(this.BUTTON_SZUKAJ_PACJENTA_Click);
            // 
            // TEXT_BOX_PESEL
            // 
            this.TEXT_BOX_PESEL.Location = new System.Drawing.Point(281, 45);
            this.TEXT_BOX_PESEL.Name = "TEXT_BOX_PESEL";
            this.TEXT_BOX_PESEL.Size = new System.Drawing.Size(100, 20);
            this.TEXT_BOX_PESEL.TabIndex = 5;
            // 
            // TEXT_BOX_NAZWISKO
            // 
            this.TEXT_BOX_NAZWISKO.Location = new System.Drawing.Point(153, 45);
            this.TEXT_BOX_NAZWISKO.Name = "TEXT_BOX_NAZWISKO";
            this.TEXT_BOX_NAZWISKO.Size = new System.Drawing.Size(100, 20);
            this.TEXT_BOX_NAZWISKO.TabIndex = 4;
            // 
            // TEXT_BOX_IMIONA
            // 
            this.TEXT_BOX_IMIONA.Location = new System.Drawing.Point(27, 45);
            this.TEXT_BOX_IMIONA.Name = "TEXT_BOX_IMIONA";
            this.TEXT_BOX_IMIONA.Size = new System.Drawing.Size(100, 20);
            this.TEXT_BOX_IMIONA.TabIndex = 3;
            // 
            // LABEL_PESEL
            // 
            this.LABEL_PESEL.AutoSize = true;
            this.LABEL_PESEL.Location = new System.Drawing.Point(278, 29);
            this.LABEL_PESEL.Name = "LABEL_PESEL";
            this.LABEL_PESEL.Size = new System.Drawing.Size(44, 13);
            this.LABEL_PESEL.TabIndex = 2;
            this.LABEL_PESEL.Text = "PESEL:";
            // 
            // LABEL_NAZWISKO
            // 
            this.LABEL_NAZWISKO.AutoSize = true;
            this.LABEL_NAZWISKO.Location = new System.Drawing.Point(150, 29);
            this.LABEL_NAZWISKO.Name = "LABEL_NAZWISKO";
            this.LABEL_NAZWISKO.Size = new System.Drawing.Size(68, 13);
            this.LABEL_NAZWISKO.TabIndex = 1;
            this.LABEL_NAZWISKO.Text = "NAZWISKO:";
            // 
            // LABEL_IMIONA
            // 
            this.LABEL_IMIONA.AutoSize = true;
            this.LABEL_IMIONA.Location = new System.Drawing.Point(24, 29);
            this.LABEL_IMIONA.Name = "LABEL_IMIONA";
            this.LABEL_IMIONA.Size = new System.Drawing.Size(48, 13);
            this.LABEL_IMIONA.TabIndex = 0;
            this.LABEL_IMIONA.Text = "IMIONA:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(335, 124);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(902, 294);
            this.dataGridView1.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.BUTTON_ZAPISZ);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.TEXT_BOX_DODAJ_NR_TELEFONU);
            this.groupBox2.Controls.Add(this.TEXT_BOX_DODAJ_NR_LOK);
            this.groupBox2.Controls.Add(this.TEXT_BOX_DODAJ_NR_BUD);
            this.groupBox2.Controls.Add(this.TEXT_BOX_DODAJ_ULICE);
            this.groupBox2.Controls.Add(this.TEXT_BOX_DODAJ_KOD_POCZTOWY);
            this.groupBox2.Controls.Add(this.TEXT_BOX_DODAJ_MIAST0);
            this.groupBox2.Controls.Add(this.TEXT_BOX_DODAJ_PESEL);
            this.groupBox2.Controls.Add(this.TEXT_BOX_DODAJ_NAZWISKO);
            this.groupBox2.Controls.Add(this.TEXT_BOX_DODAJ_IMIE);
            this.groupBox2.Location = new System.Drawing.Point(21, 125);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(308, 545);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DODANIE/EDYCJA DAYCH PACJENTA";
            // 
            // BUTTON_ZAPISZ
            // 
            this.BUTTON_ZAPISZ.Location = new System.Drawing.Point(18, 364);
            this.BUTTON_ZAPISZ.Name = "BUTTON_ZAPISZ";
            this.BUTTON_ZAPISZ.Size = new System.Drawing.Size(75, 23);
            this.BUTTON_ZAPISZ.TabIndex = 18;
            this.BUTTON_ZAPISZ.Text = "ZAPISZ";
            this.BUTTON_ZAPISZ.UseVisualStyleBackColor = true;
            this.BUTTON_ZAPISZ.Click += new System.EventHandler(this.BUTTON_ZAPISZ_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 280);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(139, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "TELEFON KONTAKTOWY:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(218, 247);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(12, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "/";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(163, 228);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "NUMER:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 228);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "ULICA:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(163, 182);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "KOD_POCZTOWY:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 182);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "MIASTO:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "PESEL:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "NAZWISKO:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "IMIONA:";
            // 
            // TEXT_BOX_DODAJ_NR_TELEFONU
            // 
            this.TEXT_BOX_DODAJ_NR_TELEFONU.Location = new System.Drawing.Point(18, 296);
            this.TEXT_BOX_DODAJ_NR_TELEFONU.Name = "TEXT_BOX_DODAJ_NR_TELEFONU";
            this.TEXT_BOX_DODAJ_NR_TELEFONU.Size = new System.Drawing.Size(100, 20);
            this.TEXT_BOX_DODAJ_NR_TELEFONU.TabIndex = 8;
            this.TEXT_BOX_DODAJ_NR_TELEFONU.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TEXT_BOX_DODAJ_NR_TELEFONU_KeyPress);
            // 
            // TEXT_BOX_DODAJ_NR_LOK
            // 
            this.TEXT_BOX_DODAJ_NR_LOK.Location = new System.Drawing.Point(236, 244);
            this.TEXT_BOX_DODAJ_NR_LOK.Name = "TEXT_BOX_DODAJ_NR_LOK";
            this.TEXT_BOX_DODAJ_NR_LOK.Size = new System.Drawing.Size(47, 20);
            this.TEXT_BOX_DODAJ_NR_LOK.TabIndex = 7;
            this.TEXT_BOX_DODAJ_NR_LOK.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TEXT_BOX_DODAJ_NR_LOK_KeyPress);
            // 
            // TEXT_BOX_DODAJ_NR_BUD
            // 
            this.TEXT_BOX_DODAJ_NR_BUD.Location = new System.Drawing.Point(166, 244);
            this.TEXT_BOX_DODAJ_NR_BUD.Name = "TEXT_BOX_DODAJ_NR_BUD";
            this.TEXT_BOX_DODAJ_NR_BUD.Size = new System.Drawing.Size(46, 20);
            this.TEXT_BOX_DODAJ_NR_BUD.TabIndex = 6;
            this.TEXT_BOX_DODAJ_NR_BUD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TEXT_BOX_DODAJ_NR_BUD_KeyPress);
            // 
            // TEXT_BOX_DODAJ_ULICE
            // 
            this.TEXT_BOX_DODAJ_ULICE.Location = new System.Drawing.Point(18, 244);
            this.TEXT_BOX_DODAJ_ULICE.Name = "TEXT_BOX_DODAJ_ULICE";
            this.TEXT_BOX_DODAJ_ULICE.Size = new System.Drawing.Size(100, 20);
            this.TEXT_BOX_DODAJ_ULICE.TabIndex = 5;
            this.TEXT_BOX_DODAJ_ULICE.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TEXT_BOX_DODAJ_ULICE_KeyPress);
            // 
            // TEXT_BOX_DODAJ_KOD_POCZTOWY
            // 
            this.TEXT_BOX_DODAJ_KOD_POCZTOWY.Location = new System.Drawing.Point(166, 196);
            this.TEXT_BOX_DODAJ_KOD_POCZTOWY.Name = "TEXT_BOX_DODAJ_KOD_POCZTOWY";
            this.TEXT_BOX_DODAJ_KOD_POCZTOWY.Size = new System.Drawing.Size(100, 20);
            this.TEXT_BOX_DODAJ_KOD_POCZTOWY.TabIndex = 4;
            this.TEXT_BOX_DODAJ_KOD_POCZTOWY.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TEXT_BOX_DODAJ_KOD_POCZTOWY_KeyPress);
            // 
            // TEXT_BOX_DODAJ_MIAST0
            // 
            this.TEXT_BOX_DODAJ_MIAST0.Location = new System.Drawing.Point(18, 196);
            this.TEXT_BOX_DODAJ_MIAST0.Name = "TEXT_BOX_DODAJ_MIAST0";
            this.TEXT_BOX_DODAJ_MIAST0.Size = new System.Drawing.Size(100, 20);
            this.TEXT_BOX_DODAJ_MIAST0.TabIndex = 3;
            this.TEXT_BOX_DODAJ_MIAST0.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TEXT_BOX_DODAJ_MIAST0_KeyPress);
            // 
            // TEXT_BOX_DODAJ_PESEL
            // 
            this.TEXT_BOX_DODAJ_PESEL.Location = new System.Drawing.Point(18, 147);
            this.TEXT_BOX_DODAJ_PESEL.Name = "TEXT_BOX_DODAJ_PESEL";
            this.TEXT_BOX_DODAJ_PESEL.Size = new System.Drawing.Size(100, 20);
            this.TEXT_BOX_DODAJ_PESEL.TabIndex = 2;
            this.TEXT_BOX_DODAJ_PESEL.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TEXT_BOX_DODAJ_PESEL_KeyPress);
            // 
            // TEXT_BOX_DODAJ_NAZWISKO
            // 
            this.TEXT_BOX_DODAJ_NAZWISKO.Location = new System.Drawing.Point(18, 97);
            this.TEXT_BOX_DODAJ_NAZWISKO.Name = "TEXT_BOX_DODAJ_NAZWISKO";
            this.TEXT_BOX_DODAJ_NAZWISKO.Size = new System.Drawing.Size(100, 20);
            this.TEXT_BOX_DODAJ_NAZWISKO.TabIndex = 1;
            this.TEXT_BOX_DODAJ_NAZWISKO.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TEXT_BOX_DODAJ_NAZWISKO_KeyPress);
            // 
            // TEXT_BOX_DODAJ_IMIE
            // 
            this.TEXT_BOX_DODAJ_IMIE.Location = new System.Drawing.Point(18, 46);
            this.TEXT_BOX_DODAJ_IMIE.Name = "TEXT_BOX_DODAJ_IMIE";
            this.TEXT_BOX_DODAJ_IMIE.Size = new System.Drawing.Size(100, 20);
            this.TEXT_BOX_DODAJ_IMIE.TabIndex = 0;
            this.TEXT_BOX_DODAJ_IMIE.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TEXT_BOX_DODAJ_IMIE_KeyPress);
            // 
            // zakres_dni_od
            // 
            this.zakres_dni_od.Location = new System.Drawing.Point(347, 452);
            this.zakres_dni_od.Name = "zakres_dni_od";
            this.zakres_dni_od.Size = new System.Drawing.Size(200, 20);
            this.zakres_dni_od.TabIndex = 3;
            // 
            // zakres_dni_do
            // 
            this.zakres_dni_do.Location = new System.Drawing.Point(347, 484);
            this.zakres_dni_do.Name = "zakres_dni_do";
            this.zakres_dni_do.Size = new System.Drawing.Size(200, 20);
            this.zakres_dni_do.TabIndex = 4;
            // 
            // zakres_godzin_od
            // 
            this.zakres_godzin_od.Location = new System.Drawing.Point(347, 510);
            this.zakres_godzin_od.Name = "zakres_godzin_od";
            this.zakres_godzin_od.Size = new System.Drawing.Size(91, 20);
            this.zakres_godzin_od.TabIndex = 5;
            this.zakres_godzin_od.Value = new System.DateTime(2019, 11, 12, 8, 0, 0, 0);
            // 
            // zakres_godzin_do
            // 
            this.zakres_godzin_do.Location = new System.Drawing.Point(456, 510);
            this.zakres_godzin_do.Name = "zakres_godzin_do";
            this.zakres_godzin_do.Size = new System.Drawing.Size(91, 20);
            this.zakres_godzin_do.TabIndex = 6;
            this.zakres_godzin_do.Value = new System.DateTime(2019, 11, 12, 16, 0, 0, 0);
            // 
            // button_wyszukaj_termin
            // 
            this.button_wyszukaj_termin.Location = new System.Drawing.Point(347, 536);
            this.button_wyszukaj_termin.Name = "button_wyszukaj_termin";
            this.button_wyszukaj_termin.Size = new System.Drawing.Size(200, 44);
            this.button_wyszukaj_termin.TabIndex = 7;
            this.button_wyszukaj_termin.Text = "WYSZUKAJ TERMIN";
            this.button_wyszukaj_termin.UseVisualStyleBackColor = true;
            this.button_wyszukaj_termin.Click += new System.EventHandler(this.button_wyszukaj_termin_Click);
            // 
            // button_pierwszy_wolny
            // 
            this.button_pierwszy_wolny.Location = new System.Drawing.Point(347, 586);
            this.button_pierwszy_wolny.Name = "button_pierwszy_wolny";
            this.button_pierwszy_wolny.Size = new System.Drawing.Size(200, 44);
            this.button_pierwszy_wolny.TabIndex = 8;
            this.button_pierwszy_wolny.Text = "PIERWSZY WOLNY";
            this.button_pierwszy_wolny.UseVisualStyleBackColor = true;
            this.button_pierwszy_wolny.Click += new System.EventHandler(this.button_pierwszy_wolny_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToOrderColumns = true;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(567, 452);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(670, 204);
            this.dataGridView2.TabIndex = 9;
            // 
            // REJESTRACJA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1264, 682);
            this.Controls.Add(this.BUTTON_ZAREJESTRUJ);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.button_pierwszy_wolny);
            this.Controls.Add(this.button_wyszukaj_termin);
            this.Controls.Add(this.zakres_godzin_do);
            this.Controls.Add(this.zakres_godzin_od);
            this.Controls.Add(this.zakres_dni_do);
            this.Controls.Add(this.zakres_dni_od);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox1);
            this.Name = "REJESTRACJA";
            this.Text = "REJESTRACJA";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label LABEL_NAZWISKO;
        private System.Windows.Forms.Label LABEL_IMIONA;
        private System.Windows.Forms.Button BUTTON_SZUKAJ_PACJENTA;
        private System.Windows.Forms.TextBox TEXT_BOX_PESEL;
        private System.Windows.Forms.TextBox TEXT_BOX_NAZWISKO;
        private System.Windows.Forms.TextBox TEXT_BOX_IMIONA;
        private System.Windows.Forms.Label LABEL_PESEL;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox TEXT_BOX_DODAJ_NR_TELEFONU;
        private System.Windows.Forms.TextBox TEXT_BOX_DODAJ_NR_LOK;
        private System.Windows.Forms.TextBox TEXT_BOX_DODAJ_NR_BUD;
        private System.Windows.Forms.TextBox TEXT_BOX_DODAJ_ULICE;
        private System.Windows.Forms.TextBox TEXT_BOX_DODAJ_KOD_POCZTOWY;
        private System.Windows.Forms.TextBox TEXT_BOX_DODAJ_MIAST0;
        private System.Windows.Forms.TextBox TEXT_BOX_DODAJ_PESEL;
        private System.Windows.Forms.TextBox TEXT_BOX_DODAJ_NAZWISKO;
        private System.Windows.Forms.TextBox TEXT_BOX_DODAJ_IMIE;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button BUTTON_ZAPISZ;
        private System.Windows.Forms.Button BUTTON_ZAREJESTRUJ;
        private System.Windows.Forms.DateTimePicker zakres_dni_od;
        private System.Windows.Forms.DateTimePicker zakres_dni_do;
        private System.Windows.Forms.DateTimePicker zakres_godzin_od;
        private System.Windows.Forms.DateTimePicker zakres_godzin_do;
        private System.Windows.Forms.Button button_wyszukaj_termin;
        private System.Windows.Forms.Button button_pierwszy_wolny;
        private System.Windows.Forms.DataGridView dataGridView2;
    }
}