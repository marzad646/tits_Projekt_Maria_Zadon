﻿namespace MARIA_ZADON
{
    partial class PRZYCHODNIA_MARIA
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.BUTTON_REJESTRACJA = new System.Windows.Forms.Button();
            this.BUTTON_GABINET = new System.Windows.Forms.Button();
            this.BUTTON_PANEL_ADMIN = new System.Windows.Forms.Button();
            this.button_przywolywaczka = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BUTTON_REJESTRACJA
            // 
            this.BUTTON_REJESTRACJA.Location = new System.Drawing.Point(114, 251);
            this.BUTTON_REJESTRACJA.Name = "BUTTON_REJESTRACJA";
            this.BUTTON_REJESTRACJA.Size = new System.Drawing.Size(120, 100);
            this.BUTTON_REJESTRACJA.TabIndex = 0;
            this.BUTTON_REJESTRACJA.Text = "REJESTRACJA";
            this.BUTTON_REJESTRACJA.UseVisualStyleBackColor = true;
            this.BUTTON_REJESTRACJA.Click += new System.EventHandler(this.BUTTON_REJESTRACJA_Click);
            // 
            // BUTTON_GABINET
            // 
            this.BUTTON_GABINET.Location = new System.Drawing.Point(382, 251);
            this.BUTTON_GABINET.Name = "BUTTON_GABINET";
            this.BUTTON_GABINET.Size = new System.Drawing.Size(120, 100);
            this.BUTTON_GABINET.TabIndex = 2;
            this.BUTTON_GABINET.Text = "GABINET";
            this.BUTTON_GABINET.UseVisualStyleBackColor = true;
            this.BUTTON_GABINET.Click += new System.EventHandler(this.BUTTON_GABINET_Click);
            // 
            // BUTTON_PANEL_ADMIN
            // 
            this.BUTTON_PANEL_ADMIN.Location = new System.Drawing.Point(650, 251);
            this.BUTTON_PANEL_ADMIN.Name = "BUTTON_PANEL_ADMIN";
            this.BUTTON_PANEL_ADMIN.Size = new System.Drawing.Size(120, 100);
            this.BUTTON_PANEL_ADMIN.TabIndex = 3;
            this.BUTTON_PANEL_ADMIN.Text = "PANEL ADMINISTRACYJNY";
            this.BUTTON_PANEL_ADMIN.UseVisualStyleBackColor = true;
            this.BUTTON_PANEL_ADMIN.Click += new System.EventHandler(this.BUTTON_PANEL_ADMIN_Click);
            // 
            // button_przywolywaczka
            // 
            this.button_przywolywaczka.Location = new System.Drawing.Point(965, 251);
            this.button_przywolywaczka.Name = "button_przywolywaczka";
            this.button_przywolywaczka.Size = new System.Drawing.Size(133, 100);
            this.button_przywolywaczka.TabIndex = 4;
            this.button_przywolywaczka.Text = "PRZYWOŁYWACZKA";
            this.button_przywolywaczka.UseVisualStyleBackColor = true;
            this.button_przywolywaczka.Click += new System.EventHandler(this.button_przywolywaczka_Click);
            // 
            // PRZYCHODNIA_MARIA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1264, 682);
            this.Controls.Add(this.button_przywolywaczka);
            this.Controls.Add(this.BUTTON_PANEL_ADMIN);
            this.Controls.Add(this.BUTTON_GABINET);
            this.Controls.Add(this.BUTTON_REJESTRACJA);
            this.Name = "PRZYCHODNIA_MARIA";
            this.Text = "PRZYCHODNIA";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BUTTON_REJESTRACJA;
        private System.Windows.Forms.Button BUTTON_GABINET;
        private System.Windows.Forms.Button BUTTON_PANEL_ADMIN;
        private System.Windows.Forms.Button button_przywolywaczka;
    }
}

