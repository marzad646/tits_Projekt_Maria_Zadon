﻿namespace MARIA_ZADON
{
    partial class KONSULTACJE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_wyślij = new System.Windows.Forms.Button();
            this.txt_tresc = new System.Windows.Forms.TextBox();
            this.button_polacz = new System.Windows.Forms.Button();
            this.txt_klient_port = new System.Windows.Forms.TextBox();
            this.txt_klient_adres = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_dialog = new System.Windows.Forms.TextBox();
            this.button_STOP = new System.Windows.Forms.Button();
            this.button_Start = new System.Windows.Forms.Button();
            this.txt_serwer_port = new System.Windows.Forms.TextBox();
            this.txt_serwer_adres = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button_zapisz_konsultacje = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_wyślij
            // 
            this.button_wyślij.Location = new System.Drawing.Point(80, 214);
            this.button_wyślij.Name = "button_wyślij";
            this.button_wyślij.Size = new System.Drawing.Size(644, 23);
            this.button_wyślij.TabIndex = 27;
            this.button_wyślij.Text = "WYŚLIJ PROŚBĘ O KONSULTACJE";
            this.button_wyślij.UseVisualStyleBackColor = true;
            this.button_wyślij.Click += new System.EventHandler(this.button_wyślij_Click_1);
            // 
            // txt_tresc
            // 
            this.txt_tresc.Location = new System.Drawing.Point(80, 117);
            this.txt_tresc.Multiline = true;
            this.txt_tresc.Name = "txt_tresc";
            this.txt_tresc.Size = new System.Drawing.Size(644, 91);
            this.txt_tresc.TabIndex = 26;
            // 
            // button_polacz
            // 
            this.button_polacz.Location = new System.Drawing.Point(521, 61);
            this.button_polacz.Name = "button_polacz";
            this.button_polacz.Size = new System.Drawing.Size(75, 23);
            this.button_polacz.TabIndex = 25;
            this.button_polacz.Text = "POŁĄCZ";
            this.button_polacz.UseVisualStyleBackColor = true;
            this.button_polacz.Click += new System.EventHandler(this.button_polacz_Click_1);
            // 
            // txt_klient_port
            // 
            this.txt_klient_port.Location = new System.Drawing.Point(401, 63);
            this.txt_klient_port.Name = "txt_klient_port";
            this.txt_klient_port.Size = new System.Drawing.Size(100, 20);
            this.txt_klient_port.TabIndex = 24;
            this.txt_klient_port.Text = "8920";
            // 
            // txt_klient_adres
            // 
            this.txt_klient_adres.Location = new System.Drawing.Point(188, 63);
            this.txt_klient_adres.Name = "txt_klient_adres";
            this.txt_klient_adres.Size = new System.Drawing.Size(100, 20);
            this.txt_klient_adres.TabIndex = 23;
            this.txt_klient_adres.Text = "127.0.0.1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(77, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "KLIENT ADRES:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(304, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 21;
            this.label4.Text = "KLIENT PORT:";
            // 
            // txt_dialog
            // 
            this.txt_dialog.Location = new System.Drawing.Point(80, 243);
            this.txt_dialog.Multiline = true;
            this.txt_dialog.Name = "txt_dialog";
            this.txt_dialog.Size = new System.Drawing.Size(644, 167);
            this.txt_dialog.TabIndex = 20;
            // 
            // button_STOP
            // 
            this.button_STOP.Location = new System.Drawing.Point(602, 35);
            this.button_STOP.Name = "button_STOP";
            this.button_STOP.Size = new System.Drawing.Size(75, 23);
            this.button_STOP.TabIndex = 19;
            this.button_STOP.Text = "STOP";
            this.button_STOP.UseVisualStyleBackColor = true;
            this.button_STOP.Click += new System.EventHandler(this.button_STOP_Click_1);
            // 
            // button_Start
            // 
            this.button_Start.Location = new System.Drawing.Point(521, 35);
            this.button_Start.Name = "button_Start";
            this.button_Start.Size = new System.Drawing.Size(75, 23);
            this.button_Start.TabIndex = 18;
            this.button_Start.Text = "START";
            this.button_Start.UseVisualStyleBackColor = true;
            this.button_Start.Click += new System.EventHandler(this.button_Start_Click_1);
            // 
            // txt_serwer_port
            // 
            this.txt_serwer_port.Location = new System.Drawing.Point(401, 37);
            this.txt_serwer_port.Name = "txt_serwer_port";
            this.txt_serwer_port.Size = new System.Drawing.Size(100, 20);
            this.txt_serwer_port.TabIndex = 17;
            this.txt_serwer_port.Text = "8910";
            // 
            // txt_serwer_adres
            // 
            this.txt_serwer_adres.Location = new System.Drawing.Point(188, 37);
            this.txt_serwer_adres.Name = "txt_serwer_adres";
            this.txt_serwer_adres.Size = new System.Drawing.Size(100, 20);
            this.txt_serwer_adres.TabIndex = 16;
            this.txt_serwer_adres.Text = "127.0.0.1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(77, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "SERWER ADRES:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(304, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "SERWER PORT:";
            // 
            // button_zapisz_konsultacje
            // 
            this.button_zapisz_konsultacje.Location = new System.Drawing.Point(80, 416);
            this.button_zapisz_konsultacje.Name = "button_zapisz_konsultacje";
            this.button_zapisz_konsultacje.Size = new System.Drawing.Size(644, 23);
            this.button_zapisz_konsultacje.TabIndex = 28;
            this.button_zapisz_konsultacje.Text = "ZAPISZ DANE KONSULTACJI";
            this.button_zapisz_konsultacje.UseVisualStyleBackColor = true;
            this.button_zapisz_konsultacje.Click += new System.EventHandler(this.button_zapisz_konsultacje_Click);
            // 
            // KONSULTACJE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_zapisz_konsultacje);
            this.Controls.Add(this.button_wyślij);
            this.Controls.Add(this.txt_tresc);
            this.Controls.Add(this.button_polacz);
            this.Controls.Add(this.txt_klient_port);
            this.Controls.Add(this.txt_klient_adres);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_dialog);
            this.Controls.Add(this.button_STOP);
            this.Controls.Add(this.button_Start);
            this.Controls.Add(this.txt_serwer_port);
            this.Controls.Add(this.txt_serwer_adres);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "KONSULTACJE";
            this.Text = "KONSULTACJE";
            this.Load += new System.EventHandler(this.KONSULTACJE_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_wyślij;
        private System.Windows.Forms.TextBox txt_tresc;
        private System.Windows.Forms.Button button_polacz;
        private System.Windows.Forms.TextBox txt_klient_port;
        private System.Windows.Forms.TextBox txt_klient_adres;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_dialog;
        private System.Windows.Forms.Button button_STOP;
        private System.Windows.Forms.Button button_Start;
        private System.Windows.Forms.TextBox txt_serwer_port;
        private System.Windows.Forms.TextBox txt_serwer_adres;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_zapisz_konsultacje;
    }
}