﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MARIA_ZADON
{
    public partial class PRZYCHODNIA_MARIA : Form
    {
      

        public PRZYCHODNIA_MARIA()
        {
            InitializeComponent();
            

        }
       

        private void BUTTON_REJESTRACJA_Click(object sender, EventArgs e)
        {
            REJESTRACJA Otworz_Rejestracja = new REJESTRACJA();
            Otworz_Rejestracja.Show();
        }
        private void BUTTON_GABINET_Click(object sender, EventArgs e)
        {
            GABINET Otworz_Gabinet = new GABINET();
            Otworz_Gabinet.Show();
        }

        private void BUTTON_PANEL_ADMIN_Click(object sender, EventArgs e)
        {
            PANEL_ADMINISTRACYJNY Otworz_Panel_Administracyjny = new PANEL_ADMINISTRACYJNY();
            Otworz_Panel_Administracyjny.Show();
        }

        private void button_przywolywaczka_Click(object sender, EventArgs e)
        {
            PRZYWOŁYWACZKA Otworz_Przywolywaczka = new PRZYWOŁYWACZKA();
            Otworz_Przywolywaczka.Show();
        }
    }


    
}
